//@flow
import { expect } from 'chai';

describe('the environment', () => {
	it('should at least run this test, and it should be green', () => {
		expect(true).to.be.true;
	});
});
