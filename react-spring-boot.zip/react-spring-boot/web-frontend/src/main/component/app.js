//@flow
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import {HeaderArea} from './headerarea';

ReactDOM.render(
	<HeaderArea/>,
	document.getElementById('root')
);
