import React, { Component } from 'react';

export class HeaderArea extends Component {
	render() {
		return <header>Hey u there....</header>
	}
}
