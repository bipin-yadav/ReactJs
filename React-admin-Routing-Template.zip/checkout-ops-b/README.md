# Checkout Ops

1. import repo
2. do gradle clean build
3. npm start -> id node not there on machine install it.
