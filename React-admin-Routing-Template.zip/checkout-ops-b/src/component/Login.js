import React from 'react';
import { Link } from 'react-router'

const Login = () => (
<div className="login-box">
     <div className="login-box-body col-xs-12">
         <p className="login-box-msg">Sign in to start your session</p>

           <div className="form-group has-feedback">
             <input type="email" class="form-control" placeholder="Email"/>
             <span className="glyphicon glyphicon-envelope form-control-feedback"></span>
           </div>
           <div className="form-group has-feedback">
             <input type="password" class="form-control" placeholder="Password"/>
             <span className="glyphicon glyphicon-lock form-control-feedback"></span>
           </div>
           <Link to='/home'>Login</Link>

       </div>
</div>
)

export default Login



